window.fancyHelper = true;
